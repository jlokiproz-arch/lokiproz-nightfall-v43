// V43: cache only public static files. NEVER cache authenticated API responses or private rooms.
const CACHE='lokiproz-v43-public-1';
const STATIC=new Set(['/','/index.html','/live.html','/live.js','/manifest.webmanifest','/icon-192.png','/icon-512.png']);
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll([...STATIC])).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('lokiproz-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const r=event.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==self.location.origin||!STATIC.has(u.pathname))return;
 event.respondWith(fetch(r).then(res=>{if(res.ok){let copy=res.clone();caches.open(CACHE).then(c=>c.put(r,copy))}return res}).catch(()=>caches.match(r)));
});
