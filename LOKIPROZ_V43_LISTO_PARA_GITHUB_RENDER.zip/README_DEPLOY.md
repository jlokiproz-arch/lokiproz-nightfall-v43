# LOKIPROZ V43 · repositorio preparado para Render

## Requisitos para desplegar
- Crear un repositorio GitHub nuevo y añadir los archivos de este directorio en su **raíz**, no el archivo ZIP tal cual.
- Conectar el repositorio en Render, seleccionar **Web Service**, runtime **Python**, plan **free** (si está disponible).
- Build: `pip install -r requirements.txt`; start: `sh start.sh`; health: `/health`. Render define PORT.
- No almacenar datos sensibles de producción en SQLite del plan Free: el disco es efímero y el servicio puede dormirse.
- Asegurar conexión **HTTPS** para cámara/micrófono WebRTC. Las llamadas son hasta 4 pares, solo señalización probada; probar audio/video real y TURN antes de uso amplio.
- Esta edición es una **beta**: no promete disponibilidad 24/7, persistencia duradera, llamadas en todas las redes ni escalado ilimitado.
- La app original Floot no se modifica.

## Seguridad y datos
No subir claves, contraseñas, archivos .env, bases de datos ni conversaciones privadas. El `.gitignore` bloquea esos archivos. Usuarios y mensajes del chat se almacenan en SQLite y **se perderán al reiniciar/reconstruir** en Render Free. Nunca anunciarla como servicio permanente. Para producción, migrar a base de datos duradera y a infraestructura de comunicaciones con TURN/SFU y reglas de moderación.

## Comprobación local
```bash
python -m pip install -r requirements.txt
pytest -q tests/test_community.py
sh start.sh
```
Abrir http://127.0.0.1:8000/health y http://127.0.0.1:8000/?live=1
