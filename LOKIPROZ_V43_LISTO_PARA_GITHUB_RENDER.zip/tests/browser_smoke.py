from playwright.sync_api import sync_playwright
from pathlib import Path
import time
root=Path(__file__).resolve().parents[1]
errors=[]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
 a=b.new_context(viewport={'width':395,'height':850},permissions=['camera','microphone'])
 c=b.new_context(viewport={'width':395,'height':850},permissions=['camera','microphone'])
 pa=a.new_page();pb=c.new_page()
 pa.on('pageerror',lambda e: errors.append('A '+str(e)))
 pb.on('pageerror',lambda e: errors.append('B '+str(e)))
 pa.goto('http://127.0.0.1:8877/?live=1',wait_until='domcontentloaded')
 pb.goto('http://127.0.0.1:8877/?live=1',wait_until='domcontentloaded')
 fa=pa.frame_locator('iframe[title*="Comunidad"]');fb=pb.frame_locator('iframe[title*="Comunidad"]')
 fa.locator('input[name="username"]').fill('JuniorTestV43')
 fa.locator('input[name="password"]').fill('SuperStrongPass_430')
 fa.get_by_role('button',name='Crear cuenta').click()
 fb.locator('input[name="username"]').fill('AmigoTestV43')
 fb.locator('input[name="password"]').fill('SuperStrongPass_430')
 fb.get_by_role('button',name='Crear cuenta').click()
 fa.locator('#accountName').wait_for(state='visible',timeout=8000)
 fb.locator('#accountName').wait_for(state='visible',timeout=8000)
 assert 'JuniorTestV43' in fa.locator('#accountName').inner_text()
 assert 'AmigoTestV43' in fb.locator('#accountName').inner_text()
 fa.locator('#message').fill('Hola amigo desde la aplicación de LOKIPROZ!')
 fa.locator('#chatForm button').click()
 fb.get_by_text('Hola amigo desde la aplicación de LOKIPROZ!').wait_for(timeout=8000)
 fa.locator('#newRoom input').fill('Sala Privada V43')
 fa.locator('#newRoom button').click()
 fa.get_by_text('Sala Privada V43').first.wait_for(timeout=8000)
 # WebRTC small-group smoke. Only verifies that a fake camera opens and signaling connects in localhost.
 fa.locator('#call').click()
 fa.locator('#callPanel').wait_for(state='visible',timeout=8000)
 assert fa.locator('#videos video').count()==1
 fa.locator('#hangup').click()
 fa.locator('#callPanel').wait_for(state='hidden',timeout=8000)
 pa.screenshot(path=str(root/'CAPTURA_COMUNIDAD_MOBILE.png'),full_page=True)
 fa.locator('#share').click()
 assert fa.locator('#error').inner_text()==''
 # Original app modules should still work
 pa.locator('button[data-page="fitness"]').first.click()
 assert pa.get_by_text('Fitness PRO').count()>0
 pa.locator('button[data-page="live"]').first.click()
 fa.locator('#rooms').wait_for(state='visible')
 assert not errors,errors
 print('PASS browser: two accounts; public realtime chat; private room; fake camera call; hangup; original Fitness preserved')
 print('PASS JS errors: none')
 print('PASS screenshot: CAPTURA_COMUNIDAD_MOBILE.png')
 b.close()
