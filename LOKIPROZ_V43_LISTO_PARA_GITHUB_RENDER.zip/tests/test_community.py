import importlib, os, sys, tempfile
from pathlib import Path
import pytest
from fastapi.testclient import TestClient

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def initmod(tmp_path):
    os.environ['LOKIPROZ_DB']=str(tmp_path/'test.sqlite3')
    sys.modules.pop('server',None)
    return importlib.import_module('server')

def create(client, name):
    r=client.post('/api/register',json={'username':name,'password':'SupersafePass1234'})
    assert r.status_code==200,r.text
    return r.json()['user']

def test_users_invites_rooms_messages_and_privacy(tmp_path):
    m=initmod(tmp_path)
    with TestClient(m.app) as owner, TestClient(m.app) as friend, TestClient(m.app) as stranger:
        me=create(owner,'OwnerTester'); create(friend,'FriendTester');create(stranger,'NotInvited')
        r=owner.post('/api/rooms',json={'name':'Amigos de LOKIPROZ'})
        assert r.status_code==200, r.text
        data=r.json();rid=data['room']['id'];secret=data['invite']
        assert friend.get(f'/api/rooms/{rid}/messages').status_code==403
        assert stranger.post('/api/rooms/join',json={'roomId':rid,'invite':'fake-invite-link'}).status_code==404
        assert friend.post('/api/rooms/join',json={'roomId':rid,'invite':secret}).status_code==200
        with owner.websocket_connect('/ws') as wa, friend.websocket_connect('/ws') as wb:
            assert wa.receive_json()['type']=='ready';assert wb.receive_json()['type']=='ready'
            wa.send_json({'type':'join','roomId':rid});assert wa.receive_json()['type']=='joined';assert wa.receive_json()['type']=='presence'
            wb.send_json({'type':'join','roomId':rid});assert wb.receive_json()['type']=='joined';assert wb.receive_json()['type']=='presence';assert wa.receive_json()['type']=='presence'
            wa.send_json({'type':'message','body':'Hola desde dos navegadores!'});
            msg=wa.receive_json();assert msg['message']['body']=='Hola desde dos navegadores!'
            assert wb.receive_json()['type']=='message'
            assert friend.get(f'/api/rooms/{rid}/messages').json()['messages'][-1]['body']=='Hola desde dos navegadores!'
        assert stranger.get(f'/api/rooms/{rid}/messages').status_code==403
        assert owner.get('/health').json()['ok']
        assert owner.get('/api/config').json()['maxCallParticipants']==4
    with TestClient(m.app) as back:
        r=back.post('/api/login',json={'username':'FriendTester','password':'SupersafePass1234'})
        assert r.status_code==200
        assert back.get(f'/api/rooms/{rid}/messages').json()['messages'][-1]['body']=='Hola desde dos navegadores!'

def test_invalid_users_origin_and_private_content(tmp_path):
    m=initmod(tmp_path)
    with TestClient(m.app) as c:
        assert c.get('/api/rooms').status_code==401
        assert c.post('/api/register',json={'username':'x','password':'123'}).status_code==422
        r=c.post('/api/register',headers={'Origin':'https://attacker.com'},json={'username':'alice_test','password':'LongPasswordName12'})
        assert r.status_code==403
        create(c,'AliceTesting')
        assert c.post('/api/register',json={'username':'AliceTesting','password':'AnotherLongPass1'}).status_code==409
        assert c.get('/api/rooms/general/messages').status_code==200
        assert c.post('/api/logout').status_code==200
        assert c.get('/api/rooms').status_code==401

def test_small_group_call_signaling(tmp_path):
    m=initmod(tmp_path)
    with TestClient(m.app) as a, TestClient(m.app) as b:
        create(a,'CallerOne');create(b,'CallerTwo')
        with a.websocket_connect('/ws') as sa,b.websocket_connect('/ws') as sb:
            a_id=sa.receive_json()['peerId'];b_id=sb.receive_json()['peerId']
            sa.send_json({'type':'join','roomId':'general'})
            assert sa.receive_json()['type']=='joined';sa.receive_json()
            sb.send_json({'type':'join','roomId':'general'})
            assert sb.receive_json()['type']=='joined';sb.receive_json();sa.receive_json()
            sa.send_json({'type':'rtc-join'})
            assert sa.receive_json()['members']==[]
            assert sb.receive_json()['type']=='rtc-peer-joined'
            sb.send_json({'type':'rtc-join'})
            first=sb.receive_json()
            assert first['type']=='rtc-members'
            assert first['members'][0]['peerId']==a_id
            second=sa.receive_json()
            assert second['type']=='rtc-peer-joined' and second['peerId']==b_id
            offer={'type':'offer','sdp':'v=0'}
            sa.send_json({'type':'rtc-offer','to':b_id,'data':offer})
            assert sb.receive_json()=={'type':'rtc-offer','from':a_id,'data':offer}
            sb.send_json({'type':'rtc-answer','to':a_id,'data':{'type':'answer','sdp':'v=0'}})
            assert sa.receive_json()['type']=='rtc-answer'
            sb.send_json({'type':'rtc-ice','to':a_id,'data':{'candidate':'candidate-test'}})
            assert sa.receive_json()['type']=='rtc-ice'
            sb.send_json({'type':'rtc-leave'})
            assert sa.receive_json()['type']=='rtc-peer-left'
