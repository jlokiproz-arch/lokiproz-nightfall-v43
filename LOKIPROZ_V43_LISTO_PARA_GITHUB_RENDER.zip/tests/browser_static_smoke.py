from playwright.sync_api import sync_playwright
from pathlib import Path
root=Path(__file__).resolve().parents[1]
errors=[]
html=(root/'app/live.html').read_text(encoding='utf-8')
js=(root/'app/live.js').read_text(encoding='utf-8')
html=html.replace('<script src="/live.js" defer></script>','<script>'+js+'</script>')
init='''(()=>{let username='';let num=0;let room='general';window.fetch=async (url, options={})=>{let u=String(url),method=options.method||'GET',data=options.body?JSON.parse(options.body):{};let response={};if(u==='/api/me')response={user:null};if(u.endsWith('/register')||u.endsWith('/login')){username=data.username;response={user:{id:'abc',username}}}if(u==='/api/config')response={iceServers:[],maxCallParticipants:4,turnConfigured:false};if(u==='/api/rooms')response={rooms:[{id:'general',name:'Comunidad General',private:0}]};if(u.includes('/messages'))response={messages:[]};if(u==='/api/rooms'&&method==='POST')response={room:{id:'newroom',name:data.name,private:true},invite:'secret-for-testing'};return {ok:true,json:async()=>response}},window.WebSocket=class {constructor(url){this.readyState=1;window.ws=this;setTimeout(()=>this.onopen?.(),30)}send(payload){let msg=JSON.parse(payload);if(msg.type==='join'){this.onmessage?.({data:JSON.stringify({type:'joined',roomId:msg.roomId,peerId:'me123',count:1})})}if(msg.type==='message'){this.onmessage?.({data:JSON.stringify({type:'message',message:{body:msg.body,username,created_at:1780000000,id:++num}})})}if(msg.type==='rtc-join'){this.onmessage?.({data:JSON.stringify({type:'rtc-members',members:[]})})}}close(){this.readyState=3}};window.WebSocket.OPEN=1;Object.defineProperty(navigator,'mediaDevices',{configurable:true,value:{getUserMedia:async()=>new MediaStream()}})})();'''
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--use-fake-ui-for-media-stream','--use-fake-device-for-media-stream'])
    page=b.new_page(viewport={'width':395,'height':860})
    page.evaluate(init)
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(html,wait_until='domcontentloaded')
    page.locator('input[name=username]').fill('juniorv43')
    page.locator('input[name=password]').fill('safepassword123')
    page.get_by_role('button',name='Crear cuenta').click()
    page.locator('#workspace').wait_for(state='visible',timeout=4000)
    page.locator('#message').fill('Hola LOKIPROZ grupo!')
    page.locator('#chatForm button').click()
    page.get_by_text('Hola LOKIPROZ grupo!').wait_for(timeout=5000)
    page.locator('#newRoom input').fill('Sala de amigos')
    page.locator('#newRoom button').click()
    page.locator('#call').click()
    page.locator('#callPanel').wait_for(state='visible')
    page.locator('#mute').click();page.locator('#camera').click()
    page.locator('#hangup').click()
    page.locator('#callPanel').wait_for(state='hidden')
    page.screenshot(path=str(root/'CAPTURA_COMUNIDAD_MOBILE.png'),full_page=True)
    print('UI mock: register, chat, room, call start/mute/camera/hangup PASS')
    print('UI script exceptions:',errors)
    assert not errors
    personal=b.new_page(viewport={'width':395,'height':850})
    personal.set_default_timeout(3000)
    personal.on('pageerror',lambda e:errors.append('main '+str(e)))
    source=(root/'app/index.html').read_text(encoding='utf-8')
    personal.evaluate("""() => {let v={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>v[k]??null,setItem:(k,x)=>v[k]=String(x),removeItem:k=>delete v[k],clear:()=>{v={}}}})}""")
    personal.set_content(source,wait_until='domcontentloaded',timeout=7000)
    assert personal.locator('button[data-page="live"]').count()>=1
    personal.locator('button[data-page="fitness"]:visible').first.click(timeout=3000)
    assert personal.locator('[data-v42="exercise"]').count()>0
    print('Original personal app + added Community tab + Fitness route PASS',flush=True)
    assert not errors,errors
    b.close()
