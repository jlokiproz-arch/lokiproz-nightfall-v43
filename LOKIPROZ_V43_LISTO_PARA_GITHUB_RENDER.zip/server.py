"""LOKIPROZ V43: HTTPS-ready realtime chat and small-room WebRTC signaling.
Not a limitless scalable conferencing service. Use durable DB_VOLUME and HTTPS for production.
"""
from __future__ import annotations
import asyncio
import hashlib
import json
import os
import re
import secrets
import sqlite3
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from pathlib import Path
from urllib.parse import urlsplit

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException, Depends
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

HERE = Path(__file__).resolve().parent
DB = Path(os.environ.get('LOKIPROZ_DB', str(HERE / 'data' / 'community.sqlite3')))
DB.parent.mkdir(parents=True, exist_ok=True)
ph = PasswordHasher(time_cost=2, memory_cost=32768, parallelism=2)
SESSION_SECONDS = 7 * 86400
MAX_PEERS = 4   # Mesh WebRTC: for large rooms use a managed SFU + TURN server.
connections: dict[str, dict[str, WebSocket]] = defaultdict(dict)
video_callers: dict[str, set[str]] = defaultdict(set)
peer_names: dict[str, str] = {}
peer_rooms: dict[str, str] = {}
limits = defaultdict(deque)
lock = asyncio.Lock()


def dbconn():
    con = sqlite3.connect(DB, timeout=5)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=5000')
    return con


def initdb():
    with dbconn() as con:
        con.execute('PRAGMA journal_mode=WAL')
        con.executescript('''
          CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, created_at INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires_at INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS rooms(id TEXT PRIMARY KEY, name TEXT NOT NULL, owner_id TEXT REFERENCES users(id), invite_hash TEXT, created_at INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS memberships(room_id TEXT NOT NULL REFERENCES rooms(id), user_id TEXT NOT NULL REFERENCES users(id), PRIMARY KEY(room_id,user_id));
          CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, room_id TEXT NOT NULL REFERENCES rooms(id), user_id TEXT NOT NULL REFERENCES users(id), body TEXT NOT NULL, created_at INTEGER NOT NULL);
          CREATE INDEX IF NOT EXISTS idx_room_messages ON messages(room_id,id DESC);
        ''')
        con.execute('INSERT OR IGNORE INTO rooms(id,name,owner_id,invite_hash,created_at) VALUES(?,?,?,?,?)',('general','Comunidad General',None,None,int(time.time())))
        con.execute('DELETE FROM sessions WHERE expires_at < ?', (int(time.time()),))


def rate(key: str, max_count=15, period=60):
    now=time.monotonic(); q=limits[key]
    while q and q[0] < now-period: q.popleft()
    if len(q)>=max_count: raise HTTPException(429,'Demasiados intentos. Espera un momento.')
    q.append(now)


def origin_check(req:Request):
    origin=req.headers.get('origin')
    if origin:
        parsed=urlsplit(origin)
        if parsed.netloc.lower()!=req.headers.get('host','').lower() or parsed.scheme not in ('http','https'):
            raise HTTPException(403,'Origen no permitido')


def secure(req:Request):
    return req.url.scheme=='https' or req.headers.get('x-forwarded-proto','').lower()=='https'


def user_for_token(raw: str | None):
    if not raw: return None
    with dbconn() as con:
        r=con.execute('SELECT u.id,u.username FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?',(hashlib.sha256(raw.encode()).hexdigest(),int(time.time()))).fetchone()
        return dict(r) if r else None


def current(req:Request):
    u=user_for_token(req.cookies.get('lokiproz_session'))
    if not u: raise HTTPException(401,'Inicia sesión para entrar a la comunidad')
    return u


def is_member(uid: str, rid: str):
    if rid=='general': return True
    with dbconn() as con:
        return con.execute('SELECT 1 FROM memberships WHERE room_id=? AND user_id=?',(rid,uid)).fetchone() is not None


@asynccontextmanager
async def lifespan(app):
    initdb()
    yield

app=FastAPI(title='LOKIPROZ Comunidad', lifespan=lifespan, docs_url=None, redoc_url=None)

@app.middleware('http')
async def headers(request, call_next):
    res=await call_next(request)
    res.headers['X-Content-Type-Options']='nosniff'
    res.headers['Referrer-Policy']='strict-origin-when-cross-origin'
    res.headers['X-Frame-Options']='SAMEORIGIN'  # /live.html is embedded by our own app
    res.headers['Permissions-Policy']='camera=(self), microphone=(self), geolocation=()'
    res.headers['Cache-Control']='no-store' if request.url.path.startswith('/api') else 'no-cache'
    return res

class Credentials(BaseModel):
    username: str=Field(min_length=3,max_length=24)
    password: str=Field(min_length=10,max_length=128)

class RoomCreate(BaseModel):
    name: str=Field(min_length=3,max_length=55)

class RoomJoin(BaseModel):
    roomId:str=Field(min_length=1,max_length=80)
    invite:str=Field(min_length=8,max_length=128)

@app.get('/health')
async def health():
    with dbconn() as con: con.execute('SELECT 1').fetchone()
    return {'ok':True, 'version':'43.0', 'persistence':'sqlite', 'callMode':'p2p-mesh'}

@app.get('/api/me')
async def me(request:Request):
    u=user_for_token(request.cookies.get('lokiproz_session'))
    return {'user':u,'limits':{'videoParticipants':MAX_PEERS},'environment':'shared-server'}


def sign_in(res:JSONResponse, uid:str):
    raw=secrets.token_urlsafe(48)
    with dbconn() as con:
        con.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(raw.encode()).hexdigest(),uid,int(time.time())+SESSION_SECONDS))
    return raw

@app.post('/api/register')
async def register(creds:Credentials, req:Request):
    origin_check(req);rate('register:'+req.client.host,5,600)
    if not re.fullmatch(r'[a-zA-Z0-9_]{3,24}',creds.username): raise HTTPException(400,'Usuario: solo letras, números y guion bajo')
    uid=secrets.token_hex(16)
    try:
        with dbconn() as con:
            con.execute('INSERT INTO users VALUES(?,?,?,?)',(uid,creds.username,ph.hash(creds.password),int(time.time())))
    except sqlite3.IntegrityError:
        raise HTTPException(409,'Ese nombre de usuario ya está registrado')
    res=JSONResponse({'user':{'id':uid,'username':creds.username}})
    res.set_cookie('lokiproz_session',sign_in(res,uid),max_age=SESSION_SECONDS,httponly=True,secure=secure(req),samesite='lax',path='/')
    return res

@app.post('/api/login')
async def login(creds:Credentials,req:Request):
    origin_check(req);rate('login:'+req.client.host,12,300)
    with dbconn() as con:
        u=con.execute('SELECT id,username,password_hash FROM users WHERE username=?',(creds.username,)).fetchone()
    if not u: raise HTTPException(401,'Usuario o contraseña incorrectos')
    try: ph.verify(u['password_hash'],creds.password)
    except (VerifyMismatchError,VerificationError): raise HTTPException(401,'Usuario o contraseña incorrectos')
    res=JSONResponse({'user':{'id':u['id'],'username':u['username']}})
    res.set_cookie('lokiproz_session',sign_in(res,u['id']),max_age=SESSION_SECONDS,httponly=True,secure=secure(req),samesite='lax',path='/')
    return res

@app.post('/api/logout')
async def logout(req:Request):
    origin_check(req)
    raw=req.cookies.get('lokiproz_session')
    if raw:
        with dbconn() as con: con.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(raw.encode()).hexdigest(),))
    res=JSONResponse({'ok':True});res.delete_cookie('lokiproz_session',path='/');return res

@app.get('/api/rooms')
async def rooms(u=Depends(current)):
    with dbconn() as con:
        rows=con.execute('''SELECT r.id,r.name,r.owner_id IS NOT NULL AS private FROM rooms r
        WHERE r.id='general' OR EXISTS(SELECT 1 FROM memberships m WHERE m.room_id=r.id AND m.user_id=?)
        ORDER BY r.created_at''',(u['id'],)).fetchall()
    return {'rooms':[dict(x) for x in rows]}

@app.post('/api/rooms')
async def make_room(body:RoomCreate,req:Request,u=Depends(current)):
    origin_check(req);rate('room:'+u['id'],6,3600)
    name=body.name.strip()
    if len(name)<3: raise HTTPException(400,'Nombre demasiado corto')
    rid=secrets.token_urlsafe(12);invite=secrets.token_urlsafe(24)
    with dbconn() as con:
        con.execute('INSERT INTO rooms VALUES(?,?,?,?,?)',(rid,name,u['id'],hashlib.sha256(invite.encode()).hexdigest(),int(time.time())))
        con.execute('INSERT INTO memberships VALUES(?,?)',(rid,u['id']))
    return {'room':{'id':rid,'name':name,'private':True},'invite':invite}

@app.post('/api/rooms/join')
async def join_room(body:RoomJoin,req:Request,u=Depends(current)):
    origin_check(req);rate('join:'+u['id'],20,600)
    with dbconn() as con:
        r=con.execute('SELECT invite_hash FROM rooms WHERE id=?',(body.roomId,)).fetchone()
        if not r or not r['invite_hash'] or not secrets.compare_digest(r['invite_hash'],hashlib.sha256(body.invite.encode()).hexdigest()):
            raise HTTPException(404,'Invitación inválida')
        con.execute('INSERT OR IGNORE INTO memberships VALUES(?,?)',(body.roomId,u['id']))
    return {'ok':True,'roomId':body.roomId}

@app.get('/api/rooms/{rid}/messages')
async def room_messages(rid:str,u=Depends(current)):
    if not is_member(u['id'],rid): raise HTTPException(403,'No perteneces a esta sala')
    with dbconn() as con:
        rows=con.execute('SELECT m.id,u.username,m.body,m.created_at FROM messages m JOIN users u ON u.id=m.user_id WHERE m.room_id=? ORDER BY m.id DESC LIMIT 100',(rid,)).fetchall()
    return {'messages':[dict(r) for r in reversed(rows)]}

@app.get('/api/config')
async def call_config(u=Depends(current)):
    ice=[{'urls':'stun:stun.l.google.com:19302'}]
    if os.getenv('LOKIPROZ_TURN_URL'):
        ice.append({'urls':os.environ['LOKIPROZ_TURN_URL'], 'username':os.getenv('LOKIPROZ_TURN_USER',''), 'credential':os.getenv('LOKIPROZ_TURN_PASSWORD','')})
    return {'iceServers':ice,'maxCallParticipants':MAX_PEERS,'turnConfigured':len(ice)>1}

async def emit_room(rid, data, exclude=None):
    async with lock: targets=[s for pid,s in connections[rid].items() if pid!=exclude]
    for ws in targets:
        try: await ws.send_json(data)
        except Exception: pass

@app.websocket('/ws')
async def realtime(ws:WebSocket):
    org=ws.headers.get('origin')
    if org:
        parts=urlsplit(org)
        if parts.netloc.lower()!=ws.headers.get('host','').lower() or parts.scheme not in ('http','https'):
            await ws.close(code=1008);return
    u=user_for_token(ws.cookies.get('lokiproz_session'))
    if not u: await ws.close(code=1008);return
    await ws.accept()
    rid=None;pid=secrets.token_urlsafe(12);nmsg=deque()
    try:
        await ws.send_json({'type':'ready','peerId':pid})
        while True:
            msg=await ws.receive_json()
            if not isinstance(msg,dict):continue
            typ=msg.get('type')
            if typ=='join':
                desired=str(msg.get('roomId',''))[:80]
                if not is_member(u['id'],desired):await ws.send_json({'type':'error','message':'Sin acceso a la sala'});continue
                if rid:
                    async with lock:
                        connections[rid].pop(pid,None);video_callers[rid].discard(pid)
                    await emit_room(rid,{'type':'presence','count':len(connections[rid])})
                rid=desired
                async with lock:
                    connections[rid][pid]=ws;peer_rooms[pid]=rid;peer_names[pid]=u['username']
                    count=len(connections[rid])
                await ws.send_json({'type':'joined','roomId':rid,'peerId':pid,'count':count})
                await emit_room(rid,{'type':'presence','count':count})
            elif typ=='message' and rid:
                now=time.monotonic()
                while nmsg and nmsg[0]<now-30:nmsg.popleft()
                if len(nmsg)>=15:await ws.send_json({'type':'error','message':'Espera antes de enviar más mensajes'});continue
                nmsg.append(now)
                body=msg.get('body','')
                if not isinstance(body,str):continue
                body=body.strip()
                if not 1<=len(body)<=2000:await ws.send_json({'type':'error','message':'Mensaje de 1 a 2000 caracteres'});continue
                with dbconn() as con:
                    cur=con.execute('INSERT INTO messages(room_id,user_id,body,created_at) VALUES(?,?,?,?)',(rid,u['id'],body,int(time.time())))
                    mid=cur.lastrowid
                await emit_room(rid,{'type':'message','message':{'id':mid,'username':u['username'],'body':body,'created_at':int(time.time())}})
            elif typ=='rtc-join' and rid:
                async with lock:
                    callers=video_callers[rid]
                    if len(callers)>=MAX_PEERS:await ws.send_json({'type':'error','message':'Videollamada completa (máximo 4 en esta versión)'});continue
                    existing=[{'peerId':x,'username':peer_names.get(x,'Usuario')} for x in callers if x!=pid]
                    callers.add(pid)
                await ws.send_json({'type':'rtc-members','members':existing})
                await emit_room(rid,{'type':'rtc-peer-joined','peerId':pid,'username':u['username']},exclude=pid)
            elif typ=='rtc-leave' and rid:
                async with lock: video_callers[rid].discard(pid)
                await emit_room(rid,{'type':'rtc-peer-left','peerId':pid},exclude=pid)
            elif typ in ('rtc-offer','rtc-answer','rtc-ice') and rid:
                target=str(msg.get('to',''))
                async with lock:
                    allowed=pid in video_callers[rid] and target in video_callers[rid]
                    dest=connections[rid].get(target)
                data=msg.get('data')
                if allowed and dest and isinstance(data,dict) and len(json.dumps(data))<100_000:
                    try:await dest.send_json({'type':typ,'from':pid,'data':data})
                    except Exception:pass
    except (WebSocketDisconnect,RuntimeError,ValueError,json.JSONDecodeError):
        pass
    finally:
        if rid:
            async with lock:
                connections[rid].pop(pid,None);video_callers[rid].discard(pid)
            await emit_room(rid,{'type':'rtc-peer-left','peerId':pid},exclude=pid)
            await emit_room(rid,{'type':'presence','count':len(connections[rid])})
        peer_names.pop(pid,None);peer_rooms.pop(pid,None)

@app.get('/')
async def index():return FileResponse(HERE/'app'/'index.html')
app.mount('/',StaticFiles(directory=HERE/'app', html=True),name='public')
