#!/bin/sh
set -eu
exec uvicorn server:app --host 0.0.0.0 --port "${PORT:-8000}" --proxy-headers
